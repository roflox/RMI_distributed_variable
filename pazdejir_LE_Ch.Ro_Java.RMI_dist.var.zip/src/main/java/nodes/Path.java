package nodes;

public enum Path {
    left, right
}
