#!/bin/bash

java -jar ../target/NodeImpl-jar-with-dependencies.jar -n Node1 -p 50000 -r 1099 -h 192.168.56.1