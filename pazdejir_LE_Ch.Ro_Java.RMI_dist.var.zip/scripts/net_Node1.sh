#!/bin/bash

java -jar ../target/nodeImpl-jar-with-dependencies.jar -n Node1 -p 50000 -r 1099
