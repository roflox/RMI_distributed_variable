#!/bin/bash

java -jar ../target/NodeImpl-jar-with-dependencies.jar -n Node5 -p 50002 -r 1101 -h 192.168.56.1 -A 192.168.56.103 -t Node3 -P 1099