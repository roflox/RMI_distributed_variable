#!/bin/bash

java -jar ../target/NodeImpl-jar-with-dependencies.jar -n Node4 -p 50001 -r 1100 -h 192.168.56.1 -A 192.168.56.102 -t Node2 -P 1099